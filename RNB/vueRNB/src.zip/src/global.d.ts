declare global {
	interface Window {
		initData: any
	}
}

export {}
